PrimaryLines version 1.000
by John Roettele and Matthew Lee
Open Font license

How to install Primary Lines (Windows):

   Double-click on the file PrimaryLines.ttf, then click install.

   or Right click on the file, PrimaryLines.ttf , and select "Run as Administrator" ( the install option with a shield next to it)


Comment installer les PrimaryLines:
   
   Double-cliquez sur le fichier "PrimaryLines.ttf", puis cliquez sur "Installer".

   ou Faites un clic droit sur le fichier, PrimaryLines.ttf, et sélectionnez "Exécuter en tant qu'administrateur" (l'option d'installation avec un bouclier à côté)


Questions / Des questions:
 https://langtechcameroon.info